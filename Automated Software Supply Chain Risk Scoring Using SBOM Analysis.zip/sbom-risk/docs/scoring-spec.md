# D1: Scoring Specification

**Project:** SBOM Supply Chain Risk Scoring: A Contextual Component Risk Ranking Framework (CS 690)
**Author:** William A. Davis | **Advisor:** Dr. Omar Ochoa
**Version:** 1.0 draft, October 11, 2026 | Covers tasks D (scoring criteria and weights) and E (scoring inputs and outputs)

This document defines exactly how the pipeline turns a CycloneDX SBOM into a ranked list of components. It is the gate for milestone M1: enrichment (Task G) and scoring (Task H) are built to this specification, and any change after approval is recorded in the change log at the end.

## 1. Principles

1. **Rule-based and traceable.** No machine learning or language models. Every score is a weighted sum of five named factors, and the output shows each factor's contribution.
2. **Only vulnerable components are ranked.** A component with no known vulnerability gets no score and is listed separately as "no known vulnerabilities". Depth and age alone never put a component on the risk list.
3. **Reproducible.** Each run fixes an *analysis date* and stores every raw API response, so a run can be repeated exactly from the cache.
4. **Comparable to a baseline.** Every run also produces the CVSS-only ranking from the same data.

## 2. Inputs (Task E)

| Input | Source | Used for |
|---|---|---|
| CycloneDX JSON SBOM, spec 1.4 to 1.6 | Syft or an ecosystem CycloneDX generator (see tool-selection.md) | Components, versions, purls, dependency edges |
| Root application component | `metadata.component` | Starting point for dependency depth |
| Vulnerability matches | OSV API `querybatch` by purl and version | Which vulnerabilities affect each component version; aliases (GHSA to CVE) |
| CVSS base score and vector | NVD API v2 by CVE ID; OSV `severity` when NVD has none | Factor S |
| EPSS probability | FIRST EPSS API, scores as of the analysis date | Factor E |
| Known exploited | CISA KEV catalog (JSON feed) | Factor X |
| Public exploit reference | NVD references tagged `Exploit` | Factor X |
| Version release date | Package registry (npm registry, PyPI JSON, Go module proxy `.info`, Maven Central) | Factor A |

A component without a purl, or with a purl type OSV doesn't cover, cannot be matched to vulnerabilities. It is reported as "not assessed", not as "no known vulnerabilities".

**Duplicate installs.** npm can install the same package version in several places. Components with the same purl are merged into one ranked entry, using the shallowest depth.

**Vulnerability set for a component.** All OSV records affecting that exact version, excluding withdrawn records, with records that are aliases of each other (for example a GHSA and its CVE) merged into one.

## 3. Factors

Each factor is normalized to the range 0 to 1. Factors S, E and X describe one vulnerability *v*; factors D and A describe the component *c*.

| ID | Factor | Formula | Missing data |
|---|---|---|---|
| S | Severity | CVSS base score / 10. Prefer CVSS v3.1, then v4.0, then v3.0, then v2. | Use the advisory's qualitative severity: Critical 0.95, High 0.80, Moderate 0.55, Low 0.25. If none, 0.50 and flag "severity unknown". |
| E | Exploit probability | EPSS probability for the CVE as of the analysis date | 0, flagged "no EPSS" (EPSS only covers CVE IDs) |
| X | Known exploit availability | 1.0 if the CVE is in CISA KEV; 0.5 if NVD lists a reference tagged `Exploit`; otherwise 0 | 0 |
| D | Dependency depth | 1 / depth, where depth is the shortest path from the root (direct dependency = 1, so D = 1.0, 0.5, 0.33, ...) | Unreachable from root: depth = max depth + 1, flagged |
| A | Component age | min(days from the used version's release to the analysis date / 1826, 1), so five years or older = 1.0 | 0.50, flagged "release date unknown" |

**Why these factors.**
- **S** is the industry default and the baseline, so it stays in the model.
- **E** adds the likelihood of exploitation in the next 30 days, which CVSS doesn't measure.
- **X** adds evidence that exploitation is already happening (KEV) or is easy (public exploit code).
- **D** reflects that direct dependencies are more likely to be reachable from application code and can be fixed by the project itself. A deep transitive dependency often needs an upstream release first.
- **A** reflects maintenance lag. An old pinned version is more likely to have unpatched and undiscovered issues and harder upgrade paths.

## 4. Score

For each vulnerability *v* in component *c*:

    vuln_score(v) = w1·S(v) + w2·E(v) + w3·X(v)

For the component:

    Risk(c) = max over v of vuln_score(v)  +  w4·D(c)  +  w5·A(c)

Because the weights sum to 1 and every factor is between 0 and 1, Risk is between 0 and 1. Reports show it ×100.

- **Use the single worst vulnerability, not the worst of each factor.** Taking the vulnerability with the highest combined S, E and X keeps the three values from the same vulnerability. Taking the maximum of each factor separately could pair one CVE's severity with a different CVE's EPSS. That vulnerability is the component's *driving vulnerability* and is named in the explanation.
- **Ties** are broken by number of vulnerabilities (more ranks higher), then by highest S, then alphabetically by package name.

### Default weights

| Weight | Factor | Value | Rationale |
|---|---|---|---|
| w1 | Severity S | 0.30 | Largest single weight. Severity still matters most when nothing else is known. |
| w2 | Exploit probability E | 0.25 | Strongest predictive signal for real-world exploitation. |
| w3 | Known exploit X | 0.20 | Binary-ish but decisive when present (KEV). |
| w4 | Depth D | 0.15 | Contextual adjustment. Shouldn't on its own outweigh a severe, exploited vulnerability. |
| w5 | Age A | 0.10 | Weakest evidence of the five, so the smallest weight. |
| | **Total** | **1.00** | |

Taken together, S, E and X (0.75) describe the vulnerability and D and A (0.25) describe the component's context. Weights are configuration, not code, so sensitivity runs don't change the code.

### Worked example

Here is a direct dependency (depth 1) released 3.5 years before the analysis date. It carries a CVE with CVSS 9.8, EPSS 0.94, listed in KEV:

    S = 0.98, E = 0.94, X = 1.0, D = 1.0, A = 1278/1826 = 0.70
    Risk = 0.30·0.98 + 0.25·0.94 + 0.20·1.0 + 0.15·1.0 + 0.10·0.70
         = 0.294 + 0.235 + 0.200 + 0.150 + 0.070 = 0.949  (94.9)

Compare a CVSS 9.8 CVE with EPSS 0.002 and no exploit, at depth 4, version 6 months old:

    Risk = 0.294 + 0.0005 + 0 + 0.0375 + 0.0100 = 0.342  (34.2)

The CVSS-only baseline ties these two. The contextual model separates them by about 61 points and can say why.

## 5. Explanation logic

Each ranked component gets one sentence built from its two largest weighted contributions, plus any flags. Illustrative example (made-up package and values):

> **#3 example-lib@1.2.3** (score 88.1, baseline #11): driven by CVE-0000-0001 (CVSS 7.2), which has a 0.86 EPSS exploit probability (+21.5) and is in CISA KEV (+20.0); direct dependency; version 5.2 years old. 2 vulnerabilities.

The rules:
- Name the driving vulnerability and its CVSS.
- State the two factors with the largest weighted contribution, in plain words, with their points.
- Always state depth ("direct dependency" or "N levels deep via a → b → c", using the shortest path) and version age.
- Append data-quality flags ("no EPSS", "severity unknown", "release date unknown").
- Show the baseline rank and the movement (up or down).

## 6. Outputs (Task E)

For each SBOM, the run writes the following to `results/<project>/<analysis-date>/`:

| File | Contents |
|---|---|
| `ranking.json` | Ordered list; one object per vulnerable component (schema below) |
| `ranking.csv` | Same, flattened for spreadsheets |
| `baseline.csv` | CVSS-only ranking |
| `unscored.csv` | Components with no known vulnerabilities, and components not assessed (no purl or unsupported ecosystem) |
| `run.json` | Analysis date, tool versions, weights, SBOM file and hash, API cache location, counts and flags |

`ranking.json` entry (illustrative values):

```json
{
  "rank": 3,
  "baseline_rank": 11,
  "rank_change": 8,
  "bom_ref": "example-lib@1.2.3",
  "purl": "pkg:npm/example-lib@1.2.3",
  "name": "example-lib",
  "version": "1.2.3",
  "ecosystem": "npm",
  "score": 88.1,
  "factors": {"S": 0.72, "E": 0.86, "X": 1.0, "D": 1.0, "A": 1.0},
  "contributions": {"S": 21.6, "E": 21.5, "X": 20.0, "D": 15.0, "A": 10.0},
  "driving_vulnerability": "CVE-0000-0001",
  "vulnerabilities": [
    {"id": "CVE-0000-0001", "aliases": ["GHSA-xxxx-xxxx-xxxx"], "cvss": 7.2, "cvss_version": "3.1",
     "epss": 0.86, "kev": true, "exploit_ref": true, "score": 0.631}
  ],
  "depth": 1,
  "path": ["example-lib@1.2.3"],
  "version_released": "2021-08-04",
  "flags": [],
  "explanation": "..."
}
```

## 7. Baseline

**CVSS-only ranking:** components ordered by the highest CVSS base score among their vulnerabilities, using the same vulnerability set and severity fallbacks as factor S. Ties are broken by number of vulnerabilities, then by name. The baseline therefore differs from the contextual model only in the factors, not in the data.

## 8. Evaluation measures (for D3)

| Measure | Definition | Target |
|---|---|---|
| Differentiation | Number of components in the contextual top 10 that aren't in the baseline top 10; also Kendall's τ between the two full rankings | At least 3 of 10 different in at least 3 of the 4 test projects |
| Justification | For every component that enters the top 10 relative to the baseline, its explanation names a non-CVSS factor (E, X or D) among its two largest contributions | All entering components |
| Weight stability | Change each weight by ±0.05 and ±0.10, rescaling the other four in proportion so they still sum to 1 (20 runs per project); compare each to the default ranking | Top-10 overlap ≥ 8 of 10 and Kendall's τ ≥ 0.80 in at least 90% of runs |
| Vulnerability density | Vulnerable components per depth level, and share of risk score mass at depth 1 versus deeper | Reported, no target |

For projects with fewer than 10 vulnerable components, "top 10" means all of them.

## 9. Known limitations

- **Freeze-file depth.** A requirements file produced by `pip freeze` doesn't say which packages the application asked for. For PyGoat, direct dependencies are the packages no other package requires plus the ones the source imports directly (see test-projects.md).
- **Go "direct" is broad.** Go module graphs list every module the build selects. Depth for Go is shallower than for npm or Maven, so D is less discriminating there.
- **EPSS covers CVEs only.** GHSA-only advisories get E = 0 and a flag.
- **Reachability is structural, not call-graph.** Depth approximates exposure; it doesn't prove the vulnerable function is called.

## 10. Approval and change log

| Date | Change | Approved |
|---|---|---|
| Oct 11, 2026 | Version 1.0 draft (default weights, five factors, outputs) | Pending Dr. Ochoa written approval (M1) |
