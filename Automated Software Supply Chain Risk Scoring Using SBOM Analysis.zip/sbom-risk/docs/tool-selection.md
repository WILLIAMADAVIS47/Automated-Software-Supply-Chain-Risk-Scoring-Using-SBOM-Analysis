# Task B: SBOM Standard and Tool Selection

**Date:** October 11, 2026 | **Author:** William A. Davis

## Decision

| Item | Choice |
|---|---|
| SBOM standard | **CycloneDX JSON, spec 1.5** (1.4 to 1.6 accepted by the parser). SPDX deferred, per proposal Section I.G. |
| SBOM generation | **Ecosystem-native CycloneDX generators** for the evaluation SBOMs, because they record the dependency graph. **Syft** stays the general-purpose inventory tool and fallback. |
| Language | Python 3.11+, standard library only for parsing and graph work; pytest for tests |
| Vulnerability data (Task G) | OSV API (matching by purl and version, aliases), NVD API v2 (CVSS, exploit references), FIRST EPSS API, CISA KEV feed |

## Why not Syft alone

The proposal named "Syft or CycloneDX CLI". I ran Syft 1.18.1 against the source trees of all four test projects:

| Project | Syft components | Syft dependency edges | Native generator components | Native generator edges |
|---|---|---|---|---|
| Juice Shop (npm) | 52 (GitHub Actions only; no lockfile in repo) | 0 | 689 | 1,063 |
| PyGoat (PyPI) | 36 | 0 | 33 | 41 |
| WebGoat (Maven) | 64 | 46 | 191 | 380 |
| Gitea (Go) | 1,400 (Go plus frontend npm plus tooling) | 20 | 231 | 733 |

Syft finds packages well, but from source directories it records almost none of the parent-child relationships. Without edges there is no dependency depth, and depth is one of the five scoring factors. The CycloneDX project's own per-ecosystem generators resolve the full graph. CycloneDX CLI doesn't generate SBOMs; it converts, merges and validates them, so it plays no role in generation.

## Generators used

| Ecosystem | Tool | Version | Notes |
|---|---|---|---|
| npm | `@cyclonedx/cyclonedx-npm` | 2.1.0 | Run on a package-lock generated with `npm install --package-lock-only`; dev dependencies omitted |
| PyPI | `cyclonedx-bom` (`cyclonedx-py environment`) | 5.1.1 | Run on a virtualenv with the pinned requirements installed (Python 3.9 to match the project); root added and optional-extra edges removed by `scripts/add_root_component.py` |
| Maven | `cyclonedx-maven-plugin` (`makeAggregateBom`) | 2.9.1 | Test and provided scopes excluded |
| Go | `cyclonedx-gomod app` | 1.9.0 | Only modules linked into the `gitea` binary, not the whole module graph |
| Any | Syft | 1.18.1 | Inventory and container-image scanning; fallback when no native generator fits |

All commands are in `scripts/generate_sboms.sh` with pinned versions.

## Consequences for the proposal

- The proposal says "Syft or CycloneDX CLI depending on project type". The next package revision should say "CycloneDX ecosystem generators (Syft for inventory)".
- The pipeline is ecosystem-agnostic. It only needs a CycloneDX document with a root component and a `dependencies` section.
