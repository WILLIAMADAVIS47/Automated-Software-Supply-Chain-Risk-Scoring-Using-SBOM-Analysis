# Task C: Test Projects

**Date:** October 11, 2026 | **Author:** William A. Davis

Four open-source projects, one per major package ecosystem, each pinned to a release tag so the SBOMs can be regenerated exactly (`scripts/generate_sboms.sh`). SBOMs are in `data/sboms/`, and per-component depth tables are in `data/graphs/`.

| # | Project | Tag | Ecosystem | Components | Edges | Direct | Max depth | Why it's in the set |
|---|---|---|---|---|---|---|---|---|
| 1 | [OWASP Juice Shop](https://github.com/juice-shop/juice-shop) | v20.2.0 | npm | 689 | 1,063 | 63 | 7 | Large, deep npm tree; intentionally pins old vulnerable packages (for example jsonwebtoken 0.4.0, sanitize-html 1.4.2) |
| 2 | [OWASP PyGoat](https://github.com/adeyosemanputra/pygoat) | v2.0.1 | PyPI | 33 | 41 | 16 | 3 | Small Python/Django app with old pins (Django 4.1.7, PyYAML 5.1, cryptography 39.0.1); a small case where every ranking can be checked by hand |
| 3 | [OWASP WebGoat](https://github.com/WebGoat/WebGoat) | v2026.4 | Maven | 191 | 380 | 37 | 8 | Deepest tree; current Spring Boot stack plus deliberately old libraries (for example jjwt 0.9.1) |
| 4 | [Gitea](https://github.com/go-gitea/gitea) | v1.21.0 (2023) | Go | 231 | 733 | 110 | 3 | Real production software, not a training app; a 2023 release, so it has real, fixed-later vulnerabilities (for example golang.org/x/crypto v0.14.0) |

Edge counts include the root's edges to its direct dependencies.

## Selection criteria

1. **Public source and a reproducible build input.** That means a lockfile, pinned requirements, a Maven POM, or go.mod.
2. **Different ecosystems.** Depth structure differs a lot between them: Go is shallow, while npm and Maven are deep. This tests whether the depth factor behaves sensibly across them.
3. **Known vulnerabilities present.** Without them, ranking can't be compared to the baseline.
4. **A mix of training apps and production software.** Three OWASP apps are intentionally vulnerable. That guarantees enough vulnerable components, but it may overstate how often contextual scoring changes the order. Gitea is the real-world check on that bias.

## Notes per project

- **Juice Shop** has no committed lockfile. One was generated on Oct 11, 2026 with `npm install --package-lock-only`. Exact pins in package.json keep this close to the release, but semver ranges resolve to versions current on that date. Record this date in the evaluation.
- **PyGoat's** `requirements.txt` is a full freeze, so "direct" dependencies were inferred two ways:
  - packages no other installed package requires;
  - packages the source imports directly: Django, requests, PyJWT, PyYAML, argon2-cffi, Pillow, django-heroku.

  The generator also records optional "extras" (such as cryptography's test extra) as real dependencies, so 10 such edges are removed using `pipdeptree` as the reference. See `scripts/add_root_component.py` and `docs/validation.md`.
- **WebGoat's** release tag builds as `2026.4-SNAPSHOT` in its POM. That's cosmetic; the dependency versions come from the tagged POM.
- **Gitea** pins the Go modules linked into the server binary. Its npm frontend and Python tooling are out of scope for this SBOM.

## Possible fifth project

If time allows during evaluation, add a second real-world project. A Java service from the Log4Shell era (log4j-core 2.14.x) would give a well-known KEV case for the explanation examples.
