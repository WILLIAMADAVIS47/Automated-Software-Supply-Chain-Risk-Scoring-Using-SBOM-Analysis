# Parser and Dependency-Graph Validation (Task F)

**Date:** October 11, 2026 | **Script:** `scripts/validate_graph.py` | **Reference outputs:** `data/validation/`

## Question

Does the parser find the same components, versions and dependency depths that each ecosystem's own package manager reports? Depth matters here because it is scoring factor D. The check compares `sbomrisk`'s view of each SBOM against an independent tool run on the same project.

## Results

| Project | Reference tool | Components matched (name + version) | Depth or edges matched | Result |
|---|---|---|---|---|
| Juice Shop (npm) | `npm ls --all --omit=dev --package-lock-only --json` | 645 of 645 (100%) | Depth: 645 of 645 (100%) | PASS |
| PyGoat (PyPI) | `pipdeptree --json` | 33 of 33 (100%) | Edges: 25 of 25, none extra | PASS (after fix 3) |
| Gitea (Go) | `go list -m -json all` | 231 of 231 in Go's build list, same versions | n/a (Go has no per-module tree) | PASS |
| WebGoat (Maven) | `mvn dependency:tree` | Not run yet | Not run yet | Pending (GUIDE.md step 4) |

## Problems found and fixed

1. **Duplicate npm installs (validator bug).** npm can install one package version in two places; for example, debug@4.4.3 sits under both sequelize and sqlite3. The first version of the check kept whichever copy it saw last, and 14 packages appeared to differ in depth. The fix is to use the shallowest copy. That gives 100% agreement. **This also applies to scoring:** the spec now says duplicate installs are merged into one ranked entry at their shallowest depth.
2. **npm aliases and Go replace directives (validator bug).** For example, `string-width-cjs` is an alias for `string-width`, and Gitea replaces `github.com/nektos/act` with `gitea.com/gitea/act`. The check now resolves both.
3. **Optional "extras" recorded as real dependencies (SBOM data bug, PyGoat).** `cyclonedx-py` listed 10 edges that pip doesn't treat as required, such as cryptography → pytz from cryptography's *test* extra and Django → argon2-cffi from an optional extra. Those false edges changed three packages' depths and hid cryptography's status as a direct dependency. `add_root_component.py --required-edges` now removes any edge pipdeptree doesn't confirm. PyGoat went from 14 to 16 direct dependencies, and its maximum depth went from 4 to 3.

## Not covered by this check

- **Maven.** Not yet compared.
- **Go depth.** Go's module graph lists every module the build considered, not a parent-child tree of what's linked. Only membership and versions are checked.
- **Vulnerabilities and scores.** These don't exist until enrichment (Task G) and scoring (Task H). Validating those against an independent scanner is planned for the evaluation (D3).
