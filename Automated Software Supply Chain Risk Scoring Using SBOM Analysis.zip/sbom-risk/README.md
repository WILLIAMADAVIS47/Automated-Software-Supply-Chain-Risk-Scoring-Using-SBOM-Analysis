# sbomrisk

This is the prototype pipeline for the CS 690 Graduate Research Project *SBOM Supply Chain Risk Scoring: A Contextual Component Risk Ranking Framework* (William A. Davis; advisor Dr. Omar Ochoa, Embry-Riddle Aeronautical University, Fall 2026).

It parses CycloneDX SBOMs, builds the dependency graph, and (from Task G onward) adds vulnerability data and ranks components with a rule-based weighted score against a CVSS-only baseline.

## Status (Oct 11, 2026)

| Task | State | Where |
|---|---|---|
| B: SBOM standard and tools | Done | `docs/tool-selection.md` |
| C: Test projects and SBOMs | Done | `docs/test-projects.md`, `data/sboms/`, `scripts/generate_sboms.sh` |
| D and E: Scoring criteria, weights, inputs and outputs (D1) | Drafted, awaiting advisor approval (M1) | `docs/scoring-spec.md` |
| F: SBOM parser and dependency graph | Core done (parsing, nested components, purls, depth, cycles, synthetic root, CLI, tests) | `src/sbomrisk/` |
| G: Vulnerability enrichment | Next (Oct 12 to 23) | |
| H: Scoring and ranking | Oct 26 to Nov 6 | |

## Usage

```bash
python -m venv .venv && . .venv/bin/activate
pip install -e '.[dev]'

sbomrisk inspect data/sboms/*.cdx.json           # summary: components, edges, depth histogram, cycles
sbomrisk graph data/sboms/pygoat-v2.0.1.cdx.json  # CSV of components with depth and fan-in/out
pytest                                            # 16 tests
```

To check the parser against each ecosystem's own tools, see `GUIDE.md` (step 4) and `docs/validation.md`.

## Layout

```
src/sbomrisk/   models.py (Component, Purl), parser.py (CycloneDX JSON), graph.py (depth, cycles, paths), cli.py
scripts/        generate_sboms.sh, add_root_component.py, validate_graph.py
data/sboms/     CycloneDX SBOMs for the four test projects
data/graphs/    per-component depth tables exported by `sbomrisk graph`
docs/           tool-selection.md (B), test-projects.md (C), scoring-spec.md (D1), validation.md
tests/          pytest suite and fixtures
```
