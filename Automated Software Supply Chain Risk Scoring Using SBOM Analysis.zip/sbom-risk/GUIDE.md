# Setup, Run and Validate Guide

This guide walks you through four steps: creating the GitHub repository, uploading the project, running it on your own machine to confirm it works, and validating the results. Each step is short.

## Step 1: Create the repository on GitHub

1. Go to <https://github.com/new>.
2. Fill in:
   - **Repository name:** `sbom-risk`. It matches the Python package (`sbomrisk`) and the folder name.
   - **Description:** `CS 690 GRP: rule-based supply chain risk scoring for CycloneDX SBOMs`
   - **Visibility:** **Private** for now; you can make it public after the defense.
   - **Leave all three "Initialize" boxes unticked.** Don't add a README, .gitignore or license, because the project already has a README and .gitignore and an extra commit would conflict.
3. Click **Create repository**. Leave the page open; it shows your repo URL, for example `https://github.com/<your-username>/sbom-risk.git`.

## Step 2: Upload the project

Download `sbom-risk.zip` from the project thread and unzip it. You get a folder named `sbom-risk` containing `README.md`, `GUIDE.md`, `pyproject.toml`, `src/`, `tests/`, `scripts/`, `docs/` and `data/`. **Upload everything in that folder.** It's 31 files and about 2 MB, with nothing to leave out.

**Option A: command line (recommended; needs git installed)**

```bash
cd path/to/sbom-risk          # the unzipped folder
git init -b main
git add .
git commit -m "Tasks B-F: tool selection, test project SBOMs, scoring spec D1, CycloneDX parser and dependency graph"
git remote add origin https://github.com/<your-username>/sbom-risk.git
git push -u origin main
```

**Option B: browser only**

On the new repo's page, click **uploading an existing file**. Open the unzipped `sbom-risk` folder and drag its *contents* (not the folder itself) into the browser, then click **Commit changes**.

The browser can hide `.gitignore` because it starts with a dot. If it's missing afterwards, create it in the repo with **Add file → Create new file**, name it `.gitignore`, and paste the lines from the copy in the zip.

**Check:** the repo's front page should show the README with the "Status (Oct 11, 2026)" table.

## Step 3: Download and run it (verify it works)

You need **Python 3.11 or newer** (`python3 --version`; on Windows, `py --version`). Nothing else is required for this step.

```bash
git clone https://github.com/<your-username>/sbom-risk.git
cd sbom-risk
python3 -m venv .venv
source .venv/bin/activate            # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -e ".[dev]"
```

**3a. Run the tests.**

```bash
pytest
```

Expected: `16 passed`.

**3b. Parse all four SBOMs.**

```bash
sbomrisk inspect data/sboms/*.cdx.json
```

On Windows PowerShell, list the files instead of using `*`:

```
sbomrisk inspect data/sboms/gitea-v1.21.0.cdx.json data/sboms/juice-shop-v20.2.0.cdx.json data/sboms/pygoat-v2.0.1.cdx.json data/sboms/webgoat-v2026.4.cdx.json
```

Expected numbers:

| SBOM | Components | Edges | Direct | Max depth | Cycles |
|---|---|---|---|---|---|
| gitea-v1.21.0 | 231 | 733 | 110 | 3 | yes (normal for Go) |
| juice-shop-v20.2.0 | 689 | 1063 | 63 | 7 | no |
| pygoat-v2.0.1 | 33 | 41 | 16 | 3 | no |
| webgoat-v2026.4 | 191 | 380 | 37 | 8 | no |

Every line should say `unreachable: 0` and `warnings: 0`.

**3c. Export one dependency table and open it in Excel.**

```bash
sbomrisk graph data/sboms/pygoat-v2.0.1.cdx.json -o pygoat.csv
```

The file has one row per package, with its depth (1 = used directly by PyGoat), how many packages depend on it (`fan_in`) and how many it depends on (`fan_out`). Spot-check: Django should be depth 1, and pycparser depth 3, reached through cryptography → cffi → pycparser.

If 3a, 3b and 3c match, the code works on your machine.

## Step 4: Validate the results

This checks that the parser's components and depths agree with each package manager's own view of the same project. `docs/validation.md` has the full write-up.

**4a. Quick check against the saved reference outputs (Python only, about 10 seconds).**

```bash
python scripts/validate_graph.py npm data/sboms/juice-shop-v20.2.0.cdx.json data/validation/juice-shop-npm-ls.json
python scripts/validate_graph.py pip data/sboms/pygoat-v2.0.1.cdx.json    data/validation/pygoat-pipdeptree.json
python scripts/validate_graph.py go  data/sboms/gitea-v1.21.0.cdx.json    data/validation/gitea-go-list.json
```

Expected: each ends with `RESULT: PASS`. npm should show 645 of 645 matched and 645 of 645 at the same depth. pip should show 25 of 25 edges. Go should show 231 of 231 at the same version.

**4b. Independent check: produce the reference outputs yourself.** This is the version to cite, because the ground truth comes from your machine rather than from mine. Each part needs that ecosystem's tool installed. Do whichever you can; Maven is the one not yet validated at all.

*Maven (WebGoat), needs JDK 25 and Maven 3.9+:*

```bash
git clone --depth 1 --branch v2026.4 https://github.com/WebGoat/WebGoat ../webgoat
cd ../webgoat
mvn -B -Denforcer.skip=true dependency:tree -Dscope=runtime -DoutputFile=../sbom-risk/mvn-tree.txt
cd ../sbom-risk
python scripts/validate_graph.py maven data/sboms/webgoat-v2026.4.cdx.json mvn-tree.txt
```

*npm (Juice Shop), needs Node 20+:*

```bash
git clone --depth 1 --branch v20.2.0 https://github.com/juice-shop/juice-shop ../juice-shop
cd ../juice-shop
npm install --package-lock-only --ignore-scripts
npm ls --all --omit=dev --package-lock-only --json > ../sbom-risk/npm-ls.json
cd ../sbom-risk
python scripts/validate_graph.py npm data/sboms/juice-shop-v20.2.0.cdx.json npm-ls.json
```

Juice Shop has no committed lockfile. A lockfile you generate on a later date may pick up newer patch versions, so a handful of mismatches there is expected; record the date you ran it.

*Go (Gitea), needs Go 1.21+:*

```bash
git clone --depth 1 --branch v1.21.0 https://github.com/go-gitea/gitea ../gitea
cd ../gitea && go list -m -json all > ../sbom-risk/go-list.json && cd ../sbom-risk
python scripts/validate_graph.py go data/sboms/gitea-v1.21.0.cdx.json go-list.json
```

**4c. Record the outcome.** Paste the `RESULT` lines into `docs/validation.md`, filling in the Maven row. Then commit:

```bash
git add docs/validation.md
git commit -m "Record independent validation results"
git push
```

If any step doesn't match what's written here, paste the output into the project thread and I'll work out why.

## Optional: regenerate the SBOMs from scratch

`scripts/generate_sboms.sh` rebuilds all four SBOMs from the tagged releases with pinned tool versions. It needs git, Node, Go, JDK 25 with Maven, `uv`, and `libpq-dev` (for PyGoat's psycopg2). You don't need it to verify or validate. It's there so the dataset is reproducible for the report.
